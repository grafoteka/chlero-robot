#include "epos_functions.h"

epos_functions::epos_functions()
{

}

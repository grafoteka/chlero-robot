# hexapodo_robot
ROS package for control the motors

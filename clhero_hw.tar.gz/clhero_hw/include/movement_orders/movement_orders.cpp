#include "movement_orders.h"

movement_orders::movement_orders()
{
    //epos_functions epos_functions_library; // = epos_functions();
}

bool movement_orders::stop(int motor)
{
    //bool flag = epos_functions_library::HaltMovementOrder(motor);
    return motor;

}
